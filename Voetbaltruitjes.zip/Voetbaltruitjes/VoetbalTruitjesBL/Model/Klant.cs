﻿using System.Security;
using VoetbalTruitjesBL.Exceptions;

namespace VoetbalTruitjesBL.Model
{
    public class Klant
    {
        private string _naam;
        private string _adres;
        private List<Bestelling> _bestellingen;
        private double _korting = 1;

        public int Id {  get; set; }
        public string Name
        {
            get { return _naam; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new DomeinException("Klant_Naam");
                }
                _naam = value;
            }
        }

        public string Adres
        {
            get { return _adres; }
            set
            {
                if (string.IsNullOrEmpty(value) || value.Length<5)
                {
                    throw new DomeinException("Klant_Adres");
                }
                _adres = value;
            }
        }

        public List<Bestelling> Bestellingen
        {
            get { return _bestellingen; }
            set
            {
                if((value == null) || (value.Count<1)) {
                    throw new DomeinException("Klant_Bestellingen");
                }
                _bestellingen = value;
            }
        }
        public double Korting { get; }

        public void PlaatsBestelling(Bestelling bestelling)
        {
            if((bestelling == null) || (_bestellingen.Contains(bestelling)))
            {
                throw new DomeinException("Klant_PlaatsBestelling");
            }
            _bestellingen.Add(bestelling);
            ControleerBestelling();
        }

        private void ControleerBestelling()
        {
            int aantalBestellingen = _bestellingen.Count;

            if(aantalBestellingen > 10)
            {
                _korting = 0.8;
            }else if(aantalBestellingen >
                5)
            {
                _korting = 0.9;
            }
        }
    }
}
