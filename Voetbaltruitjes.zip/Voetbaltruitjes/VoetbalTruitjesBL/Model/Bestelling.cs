﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VoetbalTruitjesBL.Exceptions;

namespace VoetbalTruitjesBL.Model
{
    public class Bestelling
    {
        private bool _isBetaal;
        private double _totaalPrijs;
        private Klant _klant;
        private Dictionary<Truitje,int> _truitjedictionary = new();

        public int Id;
        public DateTime BestellingsDatum { get; }
        public bool IsBetaal { get; set; }  
        public double TotaalPrijs 
        {
            get {  return _totaalPrijs; } 
            set 
            {
                if(value <= 0)
                {
                    throw new DomeinException("Bestelling_TotaalPrijs");
                }
                _totaalPrijs = value * _klant.Korting;
            }
        }

        public Klant Klant
        {
            get { return _klant; }
            set
            {
                if(value == null)
                {
                    throw new DomeinException("Bestelling_Klant");
                }
                _klant = value;
            }
        }

        public Dictionary<Truitje, int> Truitjedictionary
        {
            get { return _truitjedictionary; }
            set
            {
                if((value == null) || (value.Count < 1))
                {
                    throw new DomeinException("Truitje_Dictionary");
                }
                _truitjedictionary = value;
            }
        }

        public void VoegTruitjeToe(Truitje truitje)
        {
            if((truitje == null))
            {
                throw new DomeinException("Bestelling_VoegTruitjeToe");
            }

            if (_truitjedictionary.ContainsKey(truitje))
            {
                _truitjedictionary[truitje]++;
            }
            else
            {
                _truitjedictionary.Add(truitje, 1);
            }
        }

        public void VerwijderTruitje(Truitje truitje)
        {
            if ((truitje == null))
            {
                throw new DomeinException("Bestelling_VerwijderTruitje");
            }

            if (_truitjedictionary.ContainsKey(truitje))
            {
                if (_truitjedictionary[truitje] > 1) { _truitjedictionary[truitje]--; }
                else _truitjedictionary.Remove(truitje);
            }
            else
            {
                _truitjedictionary.Add(truitje, 1);
            }
        }

    }
}
